# Building a Netflix Clone in Flutter: A Step-by-Step Guide

Welcome to my Flutter Netflix clone project! Using TMDB APIs, I've crafted an app where users can explore popular movies and series, search for specific titles, and dive into detailed views. Stay tuned for upcoming features like favorites, ratings, and cast information. Join me as we build the ultimate streaming experience together

Channel Link : https://www.youtube.com/@FlutterSync-0703

BaseUrl : https://api.themoviedb.org/3/

ImageUrl = https://image.tmdb.org/t/p/w500

Postman Collection Link : https://api.postman.com/collections/19824375-8a36a157-bce2-4baf-8acb-751643cbc473?access_key=PMAT-01HP2MMT6CNNFGHDSMNN70DZ5H

<img src="https://github.com/banku27/Youtube-Hostel-Management-App/assets/55456058/32bbce88-ba64-47f0-8af3-28e444186d72">

